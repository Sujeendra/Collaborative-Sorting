^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package euro_pallet
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.0 (2018-09-11)
------------------
* Merge branch 'master' into master
* Contributors: Henrik Andreasson

0.3.0 (2018-08-24)
------------------
* Merge branch 'master' of https://github.com/OrebroUniversity/navigation_oru-release
* Merge branch 'master' of https://github.com/OrebroUniversity/navigation_oru-release
* Contributors: Henrik Andreasson

0.2.2 (2018-01-18)
------------------
* Updated DEPENDS and CATKIN_DEPENDS.
* Contributors: Henrik Andreasson

0.2.1 (2017-09-19)
------------------
* merge
* Contributors: Martin Magnusson

0.2.0 (2017-09-15)
------------------

0.1.1 (2017-06-13)
------------------

0.1.0 (2017-06-13)
------------------

0.0.10 (2017-06-12)
-------------------

0.0.9 (2017-06-09)
------------------

0.0.8 (2017-06-08)
------------------

0.0.7 (2017-06-08)
------------------

0.0.6 (2017-06-08)
------------------

0.0.5 (2017-06-07)
------------------

0.0.4 (2017-06-07)
------------------

0.0.3 (2017-06-07)
------------------

0.0.2 (2017-05-25)
------------------

0.0.1 (2017-05-23)
------------------
* Fixed install params.
* Added visualization_msgs dep.
* Initial version.
* Contributors: Henrik Andreasson
